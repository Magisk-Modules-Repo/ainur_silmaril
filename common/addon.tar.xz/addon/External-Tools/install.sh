# External Tools

chmod -R 0755 "$MODPATH"/common/addon/External-Tools
export PATH=$MODPATH/common/addon/External-Tools/tools/$ARCH:$PATH
for j in magiskboot sed tinymix xmlstarlet zip; do
  [ -f "$MODPATH/common/addon/External-Tools/tools/$ARCH/$j" ] && alias "$j"="$MODPATH/common/addon/External-Tools/tools/$ARCH/$j"
done
