##########################################################################################
#
# MMT Extended Config Script
#
##########################################################################################

##########################################################################################
# Config Flags
##########################################################################################

# Uncomment and change 'MINAPI' and 'MAXAPI' to the minimum and maximum android version for your mod
# Uncomment DYNLIB if you want libs installed to vendor for oreo+ and system for anything older
# Uncomment PARTOVER if you have a workaround in place for extra partitions in regular magisk install (can mount them yourself - you will need to do this each boot as well). If unsure, keep commented
# Uncomment PARTITIONS and list additional partitions you will be modifying (other than system and vendor), for example: PARTITIONS="/odm /product /system_ext"
MINAPI=26
PARTOVER=true
PARTITIONS="/odm /system_ext"

##########################################################################################
# Replace list
##########################################################################################

# List all directories you want to directly replace in the system
# Check the documentations for more info why you would need this

# Construct your list in the following format
# This is an example
REPLACE_EXAMPLE="
/system/app/Youtube
/system/priv-app/SystemUI
/system/priv-app/Settings
/system/framework
"

# Construct your own list here
REPLACE="
"

##########################################################################################
# Permissions
##########################################################################################

set_permissions() {
  [ -d "$MODPATH/system/bin" ] && set_perm_recursive "$MODPATH"/system/bin 0 2000 0755 0755; set_perm_recursive "$VALI"/tools/arm64 0 0 0755 0755
  #set_perm_recursive "$MODPATH"/tools 0 0 0755 0755
  #[ -n "$T_AOC" ] && chown $(stat -c '%U:%G' /vendor/bin/hw/android.hardware.audio.service-aidl.aoc) "$MODPATH"/vendor/bin/hw/android.hardware.audio.service-aidl.aoc && chmod $(stat -c '%a' /vendor/bin/hw/android.hardware.audio.service-aidl.aoc) "$MODPATH"/vendor/bin/hw/android.hardware.audio.service-aidl.aoc && chcon $(ls -Z /vendor/bin/hw/android.hardware.audio.service-aidl.aoc | awk '{print $1}') "$MODPATH"/vendor/bin/hw/android.hardware.audio.service-aidl.aoc
  # Note that all files/folders in magisk module directory have the $MODPATH prefix - keep this prefix on all of your files/folders
  # Some examples:
  
  # For directories (includes files in them):
  # set_perm_recursive  <dirname>                <owner> <group> <dirpermission> <filepermission> <contexts> (default: u:object_r:system_file:s0)
  
  # set_perm_recursive $MODPATH/system/lib 0 0 0755 0644
  # set_perm_recursive $MODPATH/system/vendor/lib/soundfx 0 0 0755 0644

  # For files (not in directories taken care of above)
  # set_perm  <filename>                         <owner> <group> <permission> <contexts> (default: u:object_r:system_file:s0)
  
  # set_perm $MODPATH/system/lib/libart.so 0 0 0644
  # set_perm /data/local/tmp/file.txt 0 0 644
}

##########################################################################################
# MMT Extended Logic - Don't modify anything after this
##########################################################################################

SKIPUNZIP=1
unzip -qjo "$ZIPFILE" 'common/functions.sh' -d "$TMPDIR" >&2
. "$TMPDIR"/functions.sh
